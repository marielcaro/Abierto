Release Instructions
====================
PLEASE DO NOT POST A RELEASE UNLESS YOU HAVE ACCESS TO NPM

- Add a new draft release in GitHub.
- Describe the Release
- Update the CDN link in the README (@TODO: Automate?)
- `npm version 1.x.y`
- git push origin v1.x.y
- git push origin master
- Publish the release on GitHub
- `npm publish`
